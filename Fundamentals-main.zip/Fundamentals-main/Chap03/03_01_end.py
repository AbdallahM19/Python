age = 36
print(age)
print(type(age))

email_address = "john.doe@me.com"
print(email_address)
print(type(email_address))
