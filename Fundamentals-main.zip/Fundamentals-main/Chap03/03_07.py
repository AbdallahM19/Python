print("Challenge 1:")

# A message for the user
message = "This is going to be tricky ;)"
Message = "Very tricky!"
print(message) # show the message on the screen

# Perform mathematical operations
result = 2**3
print("2**3 =", result)
result = 5 - 3
#print("5 - 3 =", result)

print("Challenge complete!")