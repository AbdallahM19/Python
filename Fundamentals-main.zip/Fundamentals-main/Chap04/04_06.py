guess = input("What's my favorite food? ")

if guess == "cookies":
    print("Yep! So amazing!")
else:
    print("Yuck! That’s not it!")

print("Thanks for playing!")
