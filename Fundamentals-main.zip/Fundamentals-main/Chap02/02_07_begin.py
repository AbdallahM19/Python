print("Hello world!")

print("Goodbye world!")