# syntax error
print("Hello world")

# runtime error
10 * (2/0)

# semantic error
name = "Alice"
print("Hello name")