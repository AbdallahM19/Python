print("~~~ The Shimmy ~~~")

def shimmy():
    print("Take one step to the right and stomp.")
    print("Take one step to the left and stomp.")
    print("Shake those hips!")

shimmy()
shimmy()
shimmy()
