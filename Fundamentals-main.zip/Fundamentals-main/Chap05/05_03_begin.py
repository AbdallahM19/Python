def wash_car():
    print("Wash with tri-color foam")
    print("Rinse twice")
    print("Dry with large blow dryer")

    print("Wash with white foam")
    print("Rinse once")
    print("Air dry") 
